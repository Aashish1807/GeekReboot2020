package com.mthree;
/*SELECT customer2.*, customer.*
FROM customer2
INNER JOIN customer
ON (customer2.customer_id2 = customer.customer_id);*/
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebAndDataJpa2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebAndDataJpa2Application.class, args);
	}

}
