package com.mthree.dto;



public class CustomerDTO2 {

	
		
		private int customerId2;
		
		private String companyName;
		
		private String feedback;
		
				
		public CustomerDTO2() {}

		public CustomerDTO2(int customerId2, String companyName, String feedback) {
			super();
			this.customerId2 = customerId2;
			this.companyName = companyName;
			this.feedback = feedback;
			
		}

		public int getCustomerId2() {
			return customerId2;
		}

		public void setCustomerId2(int customerId2) {
			this.customerId2 = customerId2;
		}

		public String getCompanyName() {
			return companyName;
		}

		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}

		public String getFeedback() {
			return feedback;
		}

		public void setFeedback(String feedback) {
			this.feedback = feedback;
		}

		@Override
		public String toString() {
			return "Customer2 [customerId2=" + customerId2 + ", companyName=" + companyName + ", feedback=" + feedback + "]";
		}

				
		
	}
