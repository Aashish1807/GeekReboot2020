package com.mthree.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mthree.dto.CustomerDTO;
import com.mthree.models.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer>{
	
	
	@Query("SELECT new com.mthree.dto.CustomerDTO(c.customerId, c.customerName,c.email,c.unit) from Customer c")
	public List<CustomerDTO> findCustomersWithNoPassword();
	
		
//	@Query(value="SELECT customer_id,customer_name,email from customer",nativeQuery=true)
//	public List<Customer> findCustomersWithNoPasswordAndNativeQuery();
	
	/*@Query("DELETE new com.mthree.dto.CustomerDTO(c.customerId, c.customerName,c.email) from Customer c")
	public List<CustomerDTO> delete1();*/
	
	

}
