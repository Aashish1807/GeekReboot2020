package com.mthree.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

//import com.mthree.dto.CustomerDTO;
import com.mthree.dto.CustomerDTO2;
//import com.mthree.models.Customer;
import com.mthree.models.Customer2;

@Repository
public interface CustomerRepository2 extends JpaRepository<Customer2,Integer>{
	
	
	@Query("SELECT new com.mthree.dto.CustomerDTO2(c2.customerId2, c2.companyName,c2.feedback) from Customer2 c2")
	public List<CustomerDTO2> findCustomersWithNoPassword2();
	
	
		
//	@Query(value="SELECT customer_id2,customer_name2,feedback from customer2",nativeQuery2=true)
//	public List<Customer2> findCustomersWithNoPasswordAndNativeQuery2();
	
	

}
