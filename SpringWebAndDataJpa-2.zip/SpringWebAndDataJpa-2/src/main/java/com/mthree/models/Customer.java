package com.mthree.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer {
	
	@Id
	private int customerId;
	
	private String customerName;
	
	private String email;
	
	private String unit;
	
	
	public Customer() {}

	public Customer(int customerId, String customerName, String email,String unit) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.unit = unit;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	
	
	public String getunit() {
		return unit;
	}

	public void setunit(String unit) {
		this.unit = unit;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", unit=" + unit + "]";
	}

	
}
