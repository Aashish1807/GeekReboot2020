package com.mthree.models;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Customer2 {
	
	@Id
	private int customerId2;
	
	private String companyName;
	
	private String feedback;
	
	private String companyCode;
	
	
	public Customer2() {}

	public Customer2(int customerId2, String companyName, String feedback,String companyCode) {
		super();
		this.customerId2 = customerId2;
		this.companyName = companyName;
		this.feedback = feedback;
		this.companyCode = companyCode;
	}

	public int getCustomerId2() {
		return customerId2;
	}

	public void setCustomerId2(int customerId2) {
		this.customerId2 = customerId2;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	
	
	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	@Override
	public String toString() {
		return "Customer2 [customerId2=" + customerId2 + ", companyName=" + companyName + ", feedback=" + feedback
				+ ", companyCode=" + companyCode + "]";
	}

	
}
