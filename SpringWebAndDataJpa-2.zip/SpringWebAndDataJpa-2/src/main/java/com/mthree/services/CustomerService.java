package com.mthree.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mthree.dto.CustomerDTO;
import com.mthree.models.Customer;
import com.mthree.repositories.CustomerRepository;

@Service
public class CustomerService {
	
	
	@Autowired 
	private CustomerRepository customerRepository;
	
	
	public Customer registerCustomer(Customer c) {
		
		return customerRepository.save(c);
	}
	
	
	
	public List<CustomerDTO> loadCustomers() {
		
		//return customerRepository.findAll();
		
		return customerRepository.findCustomersWithNoPassword();
	}
	
	
	/*public List<CustomerDTO> delete() {
		
		//return customerRepository.findAll();
		
		return customerRepository.delete1();
	}*/
	
	
	

}
