package com.mthree.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mthree.dto.CustomerDTO2;
import com.mthree.models.Customer2;
import com.mthree.repositories.CustomerRepository2;

@Service
public class CustomerService2 {
	
	
	@Autowired 
	private CustomerRepository2 customerRepository2;
	
	
	public Customer2 registerCustomer2(Customer2 c2) {
		
		return customerRepository2.save(c2);
	}
	
	
	
	public List<CustomerDTO2> loadCustomers2() {
		
		//return customerRepository.findAll();
		
		return customerRepository2.findCustomersWithNoPassword2();
	}
	
	
	

}
