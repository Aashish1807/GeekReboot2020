package com.mthree.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.mthree.dto.CustomerDTO;
import com.mthree.models.Customer;
import com.mthree.services.CustomerService;


@RestController
public class CustomerController {
	
	
	@Autowired
	private CustomerService customerService;
	
	
	
	
	@PostMapping("/register_user")
	public String register(@RequestBody Customer c) {
		
		String page = null;
		
		Customer registeredCustomer = customerService.registerCustomer(c);
		
		if(registeredCustomer!=null) {
			page = "success";
		}
		else {
			page = "reg_fail";
		}

		return page;
	}
	
	
	
	@GetMapping("/user_list")
	public ModelAndView viewCustomers() {
		
		List<CustomerDTO> customerList = customerService.loadCustomers();
		
		ModelAndView mv = new ModelAndView();
		
		if(customerList.size()>0) {
		
		mv.setViewName("customer_list");
		mv.addObject("customerList", customerList);
			
		}
		else {
			mv.setViewName("empty");
		}
		
		
		return mv;
	}
	
	
	
	@PostMapping("/edit_user")
	public String edit(@RequestBody Customer c) {
		
		String page = null;
		
		Customer registeredCustomer = customerService.registerCustomer(c);
		
		if(registeredCustomer!=null) {
			page = "success";
		}
		else {
			page = "reg_fail";
		}

		return page;
	}
	
	
	

	
	
	
	

}
